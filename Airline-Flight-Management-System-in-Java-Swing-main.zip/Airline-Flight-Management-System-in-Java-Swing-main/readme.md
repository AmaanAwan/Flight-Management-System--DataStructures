AirLine Flight Management System project developed in Java Swing and consists of OOP concepts. 
User can view flight schedule without registring. 
Passenger can signup , login. 
Passenger can manage his/her profile
Passenger can book a flight 
Passenger can book local domestic flight 
Passenger can book international flight 
Passenger must have visa for applying international flight 
Passenger can cancel flight with 25% fee deduction 
Admin can Login 
Admin can add new flight Admin can remove flight Admin can update flight schedule
Admin can remove passenger booking
Admin can manage his profile
Admin can manage passengers